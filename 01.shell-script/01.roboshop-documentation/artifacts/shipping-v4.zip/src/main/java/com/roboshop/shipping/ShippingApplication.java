package com.roboshop.shipping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShippingApplication {

    public static void main(String[] args) {
        // FIPS mode: newer Java offers the post-quantum TLS group X25519MLKEM768,
        // which the FIPS provider can't generate keys for. Offer only FIPS-approved
        // groups, unless the operator already set this with -D on the command line.
        if (System.getProperty("jdk.tls.namedGroups") == null) {
            System.setProperty("jdk.tls.namedGroups", "secp256r1,secp384r1");
        }
        SpringApplication.run(ShippingApplication.class, args);
    }
}
